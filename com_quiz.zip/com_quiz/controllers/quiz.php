<?php

defined('_JEXEC') or die;

class QuizControllerQuiz extends JControllerForm {
    // Controller for individual quiz operations
}
