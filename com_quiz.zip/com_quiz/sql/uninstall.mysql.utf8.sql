DROP TABLE IF EXISTS `#__quiz_categories`;
DROP TABLE IF EXISTS `#__categories`;
DROP TABLE IF EXISTS `#__quiz_results`;
DROP TABLE IF EXISTS `#__answers`;
DROP TABLE IF EXISTS `#__questions`;
DROP TABLE IF EXISTS `#__quizzes`;
