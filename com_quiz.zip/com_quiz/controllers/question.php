<?php

defined('_JEXEC') or die;

class QuizControllerQuestion extends JControllerForm {
    // Controller for individual question operations
}
