<?php
defined('_JEXEC') or die;

class QuizControllerQuiz extends JControllerForm {
    // Controller for the Quiz component frontend quiz operations
}
